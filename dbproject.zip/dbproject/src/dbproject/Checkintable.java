/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSetMetaData;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author sxk210195
 */
public class Checkintable extends javax.swing.JFrame {

    /**
     * Creates new form Checkintable
     */
    public Checkintable() {
        initComponents();
        database_connect();
    }
     Connection connect;
     PreparedStatement pre;
     ResultSet result;
     String value="";


    public void database_connect(){
        try {
            connect = DriverManager.getConnection("jdbc:mysql://localhost/librarymanagement","root","");
            System.out.println("connected!!!!!!!!");
        } catch (SQLException ex) {
            Logger.getLogger(Borrower.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void isbn(String Isbn) {
        System.out.print(Isbn);
        try {
             pre = connect.prepareStatement("SELECT bl.Card_id,bl.Isbn,bl.Date_out FROM librarymanagement.book_loans bl left join fines f on bl.Loan_id = f.Loan_id where bl.Isbn = "+Isbn+";");
            ResultSet rs = pre.executeQuery();
             ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
             int col = rsmd.getColumnCount();
            DefaultTableModel dm = (DefaultTableModel)jTable1.getModel();
            dm.setRowCount(0);
             if(rs.getRow()>=0)
             {
                 while(rs.next()){
                Vector vec = new Vector();
                for(int i=1; i<=col; i++){
                    vec.add(rs.getString("Card_id"));
                    vec.add(rs.getString("Isbn"));
                    vec.add(rs.getString("Date_out"));
                    
                    
                }
                dm.addRow(vec);
            
            }
           }
      
             pre = connect.prepareStatement("update book_loans set date_in=sysdate() where isbn="+Isbn);
             pre.executeUpdate(); 
             
            
             
             
    }
        catch (SQLException ex) {
            Logger.getLogger(Checkintable.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void id(String iD) {
        try {
            System.out.println(iD);
            pre = connect.prepareStatement("SELECT bl.Card_id,bl.Isbn,bl.Date_out,bl.Due_date,bl.Date_in from librarymanagement.book_loans bl left outer join librarymanagement.fines f on bl.Loan_id = f.Loan_id where Card_id = " + iD + ";");
            ResultSet rs = pre.executeQuery();
             ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
             int col = rsmd.getColumnCount();
            DefaultTableModel dm = (DefaultTableModel)jTable1.getModel();
            dm.setRowCount(0);
             if(rs.getRow()>=0)
             {
                 while(rs.next()){
                Vector vec = new Vector();
                for(int i=1; i<=col; i++){
                    vec.add(rs.getString("Card_id"));
                    vec.add(rs.getString("Isbn"));
                    vec.add(rs.getString("Date_out"));
             
                }
                dm.addRow(vec);
            
            }
             }
        
             
             pre = connect.prepareStatement("update book_loans set date_in=sysdate() where card_id="+iD);
             pre.executeUpdate();  
             
             
             
      
    }
        catch (SQLException ex) {
            Logger.getLogger(Checkintable.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void name(String Name) {
        try {
             pre = connect.prepareStatement("SELECT bl.Card_id, bl.Isbn,bl.Date_out from librarymanagement.book_loans as bl left join borrower b on bl.Card_id = b.Card_id left join fines f on bl.Loan_id = f.Loan_id where Bname like '%" +Name+ "%';");
            ResultSet rs = pre.executeQuery();
             ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
             int col = rsmd.getColumnCount();
            DefaultTableModel dm = (DefaultTableModel)jTable1.getModel();
            dm.setRowCount(0);
             if(rs.getRow()>=0)
             {
                 while(rs.next()){
                Vector vec = new Vector();
                for(int i=1; i<=col; i++){
                    vec.add(rs.getString("Card_id"));
                    vec.add(rs.getString("Isbn"));
                    vec.add(rs.getString("Date_out"));
                   
                    
                }
                dm.addRow(vec);
            
            }
             }
        
             
            // pre = connect.prepareStatement("update book_loans set date_in=sysdate() where card_id="+iD);
            // pre.executeUpdate();  
      
    }
        catch (SQLException ex) {
            Logger.getLogger(Checkintable.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setBackground(new java.awt.Color(204, 255, 204));
        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Card Id", "ISBN", "Check Out Date"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setHeaderValue("Card Id");
            jTable1.getColumnModel().getColumn(1).setHeaderValue("ISBN");
            jTable1.getColumnModel().getColumn(2).setHeaderValue("Check Out Date");
        }

        jButton1.setText("<< Back");
        jButton1.setBorder(new javax.swing.border.MatteBorder(null));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("Finish >>");
        jButton3.setBorder(new javax.swing.border.MatteBorder(null));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         Checkin cin = new Checkin();
        this.hide();
        cin.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                      //  JOptionPane.showMessageDialog(this, "Book checked in successfully");
                        Frontpage f = new Frontpage();
        this.hide();
        f.setVisible(true);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        LocalDateTime lt = LocalDateTime.now();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String date = df.format(lt);
        System.out.println(date);
        try {
            pre = connect.prepareStatement("UPDATE librarymanagement.book_loans SET Date_in = '" + date + "' where Isbn = '"+ value+"';" );
            pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Checkintable.class.getName()).log(Level.SEVERE, null, ex);
        }
             
       
        JOptionPane.showMessageDialog(null, "Borrowed book is successfully checked-in");
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Checkintable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Checkintable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Checkintable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Checkintable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Checkintable().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
